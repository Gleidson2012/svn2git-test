#include "stdafx.h"
#include ".\mmlroottag.h"
#using <mscorlib.dll>

CMMLRootTag::CMMLRootTag(void)
{
}

CMMLRootTag::~CMMLRootTag(void)
{
}
