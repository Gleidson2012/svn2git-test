#pragma once

class CMMLRootTag
{
public:
	CMMLRootTag(void);
	~CMMLRootTag(void);
};
