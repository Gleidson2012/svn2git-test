#pragma once

class CMMLValidator
{
public:
	CMMLValidator(void);
	~CMMLValidator(void);
};
