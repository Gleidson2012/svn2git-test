#pragma once

class C_Import
{
public:
	C_Import(void);
	~C_Import(void);
};
