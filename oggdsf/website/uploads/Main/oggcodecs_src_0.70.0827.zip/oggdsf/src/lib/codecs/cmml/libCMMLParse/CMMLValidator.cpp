#include ".\cmmlvalidator.h"

CMMLValidator::CMMLValidator(void)
{
}

CMMLValidator::~CMMLValidator(void)
{
}
